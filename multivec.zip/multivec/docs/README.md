# Directory docs

## Scientific Paper

When you use this toolkit, please cite:

    @InProceedings{MultiVecLREC2016,
    Title                    = {{MultiVec: a Multilingual and Multilevel Representation Learning Toolkit for NLP}},
    Author                   = {Alexandre Bérard and Christophe Servan and Olivier Pietquin and Laurent Besacier},
    Booktitle                = {The 10th edition of the Language Resources and Evaluation Conference (LREC 2016)},
    Year                     = {2016},
    Month                    = {May}
    }
